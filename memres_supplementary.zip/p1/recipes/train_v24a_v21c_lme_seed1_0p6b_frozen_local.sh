#!/usr/bin/env bash
# v24a: v21c recipe trained on LongMemEval (real-content data) instead
# of synthd5_random_codes (templated synthetic). Single-variable A vs
# v23a (which was v21c on synthd5 with seed=1).
#
# Rationale: LME has 11.2 M tokens at 99.9% real-content density (vs
# synthd5's 25.6 M at 5% density = 1.3 M effective). 8.6× more F3-
# supervised real-content tokens per step. If real-content training
# fixes the variance noise floor that v22/v23 exposed at probe weight
# 0.5, this is the canonical training corpus going forward.
#
# Eval still on synthd5_val so the metric is directly comparable to
# v18-v23 cells.
#
# Single-variable change vs v23a:
#   --train_chains paper_artifacts/chains/lme_train_s512.pt
#   (was paper_artifacts/chains/synthd5_random_codes_train_s512.pt)
#
# Same seed (1) as v23a so the variance comparison is clean.
set -euo pipefail
cd "$(dirname "$0")/.."

OUT_DIR="output/chain_v24a_v21c_lme_seed1_0p6b_frozen_local"
LOG_DIR="logs"
mkdir -p "$LOG_DIR"

CUDA_VISIBLE_DEVICES=0 nohup python -u src/train_chain.py \
    --preset qwen3-0.6b-large \
    --memres_mode attention_parity \
    --router_recent_bias_init 4 --router_mem_bias_init 0 \
    --memres_update_mode gated --memres_extract_source hidden_14 \
    --memres_extract_input_norm \
    --memres_gate_init 0.0 --memres_readout_norm_init 0.05 \
    --memres_writer_kind slot_attention --memres_slot_attention_iters 3 \
    --memres_queries_init orthogonal --memres_slot_positional \
    --memres_judge_qk_layernorm \
    --memres_readout_depth 4 \
    --writer_warmup_steps 0 --writer_warmup_router_bias 0.0 --writer_warmup_anneal_steps 0 \
    --freeze_backbone \
    --readout_probe_enabled \
    --readout_probe_loss_weight 0.5 \
    --readout_probe_warmup_steps 200 \
    --alpha_mem_floor_aux_weight 0.5 \
    --alpha_mem_floor_target 0.10 \
    --train_chains paper_artifacts/chains/lme_train_s512.pt \
    --eval_chains  paper_artifacts/chains/synthd5_random_codes_val_s512.pt \
    --window_k 3 --batch_size 4 --grad_accum 2 \
    --lr 1e-4 --lr_backbone 0 --steps 1000 --warmup 200 --max_norm 1.0 \
    --memory_dropout 0.10 --context_dropout 0.05 \
    --neg_chain_weight 0.0 \
    --callback_loss_weight 5.0 --callback_window_bias 0.0 \
    --curriculum_evidence_bias 1.0 --curriculum_competition_bias 0.0 \
    --burn_in_max 0 --mask_padding_loss --score_tail_frac 1.0 \
    --mask_evidence_session_loss \
    --kill_on_memory_collapse --kill_on_memory_collapse_min_step 200 \
    --eval_every 100 --save_every 500 \
    --eval_n_chains 24 --eval_window 8 \
    --phase_aligned_eval_n_chains 64 \
    --diag_routing_n_chains 8 \
    --diagnose_grad_groups --diagnose_memory_dynamics \
    --diagnose_memory_dynamics_n_chains 8 \
    --gradient_checkpointing \
    --save_best_metric evidence_lift \
    --seed 1 \
    --run_name chain_v24a_v21c_lme_seed1_0p6b_frozen_local \
    --out_dir "$OUT_DIR" \
    > "$LOG_DIR/chain_v24a_v21c_lme_seed1_0p6b_frozen_local.log" 2>&1 &
echo "v24a launched pid=$!"
